#!/usr/bin/env bash
# ConfigCompany management CLI  (نصب‌شده با نام: configcompany)
APP_DIR=/opt/configcompany
cd "$APP_DIR" 2>/dev/null || { echo "ConfigCompany در $APP_DIR نصب نیست"; exit 1; }
R='\033[31m'; G='\033[32m'; Y='\033[33m'; N='\033[0m'
dc(){ docker compose "$@"; }
envget(){ grep -E "^$1=" .env | head -1 | cut -d= -f2-; }
confirm(){ read -rp "$1 [y/N] " a; [[ "$a" =~ ^[yY]$ ]]; }

cmd_status(){ dc ps; echo; echo "دامنه: https://$(envget DOMAIN)   پنل: https://$(envget DOMAIN)/admin-ui/   مینی‌اپ: https://$(envget DOMAIN)/miniapp/"; }
cmd_log(){ dc logs -f --tail=100 "${1:-api}"; }
cmd_backup(){
  mkdir -p backups; f="backups/cc-$(date +%Y%m%d-%H%M%S).dump"
  if dc exec -T db pg_dump -U configcompany -Fc configcompany > "$f" 2>/dev/null && [ -s "$f" ]; then
    echo -e "${G}بکاپ ساخته شد:${N} $APP_DIR/$f"; ls -1t backups/*.dump | tail -n +15 | xargs -r rm -f
  else rm -f "$f"; echo -e "${R}بکاپ ناموفق بود${N}"; return 1; fi
}
cmd_restore(){
  f="${1:-}"; [ -f "$f" ] || { ls -1t backups/*.dump 2>/dev/null | head; read -rp "مسیر فایل .dump: " f; }
  [ -f "$f" ] || { echo "فایل پیدا نشد"; return 1; }
  confirm "دیتابیس فعلی با این بکاپ جایگزین می‌شود. ادامه؟" || return 0
  cmd_backup || true
  dc stop api && dc exec -T db pg_restore --clean --if-exists -U configcompany -d configcompany < "$f"; dc start api; echo -e "${G}بازیابی انجام شد${N}"
}
cmd_token(){ id="${1:-$(envget ADMIN_TG_IDS | cut -d, -f1)}"; dc exec -T api python -m app.cli token "$id"; }
cmd_settings(){ ${EDITOR:-$(command -v nano || echo vi)} .env && dc up -d --force-recreate api caddy && echo -e "${G}اعمال شد${N}"; }
cmd_domain(){
  read -rp "دامنه‌ی جدید: " d; [ -n "$d" ] || return 1
  sed -i "s|^DOMAIN=.*|DOMAIN=$d|; s|^PUBLIC_URL=.*|PUBLIC_URL=https://$d|; s|^CORS_ORIGINS=.*|CORS_ORIGINS=https://$d|" .env
  dc up -d --force-recreate api caddy; echo "منو و مینی‌اپ را در BotFather روی https://$d/miniapp/ بگذارید."
}
cmd_update(){
  src="${1:-}"; repo="$(envget CC_REPO)"; br="$(envget CC_BRANCH)"; tmp="$(mktemp -d)"
  cmd_backup || confirm "بکاپ ناموفق بود؛ باز هم ادامه بدهم؟" || return 1
  if [ -n "$src" ] && [ -d "$src" ]; then cp -a "$src" "$tmp/src"
  elif [ -n "$repo" ] && [[ "$repo" != *YOUR_USER* ]]; then git clone -q --depth 1 -b "${br:-main}" "$repo" "$tmp/src" || { echo "دریافت ناموفق"; return 1; }
  else echo "منبع آپدیت مشخص نیست: configcompany update /مسیر/پوشه‌ی/جدید"; return 1; fi
  (cd "$tmp/src" && tar cf - --exclude=.env --exclude=backups --exclude=.git .) | tar xf -; rm -rf "$tmp"
  install -m 755 configcompany.sh /usr/local/bin/configcompany 2>/dev/null
  dc up -d --build && docker image prune -f >/dev/null; echo -e "${G}آپدیت شد${N}"
}
cmd_uninstall(){
  echo -e "${R}همه‌ی سرویس‌ها و دیتابیس حذف می‌شود!${N}"; read -rp "برای تأیید DELETE را تایپ کنید: " a; [ "$a" = DELETE ] || return 0
  cmd_backup >/dev/null 2>&1; mkdir -p /root/configcompany-last-backup; cp -f backups/*.dump /root/configcompany-last-backup/ 2>/dev/null
  dc down -v; rm -f /etc/cron.d/configcompany-backup /usr/local/bin/configcompany; cd /; rm -rf "$APP_DIR"
  echo "حذف شد. آخرین بکاپ: /root/configcompany-last-backup/"
}
menu(){
  while true; do
    echo -e "\n${G}══ ConfigCompany ══${N}
 1) وضعیت          2) شروع          3) توقف          4) ریستارت
 5) لاگ‌ها          6) آپدیت          7) بکاپ          8) بازیابی بکاپ
 9) توکن ورود پنل  10) ویرایش تنظیمات  11) تغییر دامنه  12) حذف کامل
 0) خروج"
    read -rp "انتخاب: " c
    case "$c" in 1) cmd_status;; 2) dc up -d;; 3) dc stop;; 4) dc restart;; 5) cmd_log;; 6) cmd_update;; 7) cmd_backup;; 8) cmd_restore;;
      9) cmd_token;; 10) cmd_settings;; 11) cmd_domain;; 12) cmd_uninstall;; 0) exit 0;; *) echo "نامعتبر";; esac
  done
}
case "${1:-menu}" in
  status) cmd_status;; start) dc up -d;; stop) dc stop;; restart) dc restart;; log|logs) cmd_log "${2:-}";;
  update) cmd_update "${2:-}";; backup) cmd_backup;; restore) cmd_restore "${2:-}";; token) cmd_token "${2:-}";;
  settings) cmd_settings;; domain) cmd_domain;; uninstall) cmd_uninstall;; menu) menu;;
  *) echo "استفاده: configcompany [status|start|stop|restart|log|update|backup|restore|token|settings|domain|uninstall]";;
esac
